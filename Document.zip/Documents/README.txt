1.Input table
Key UP,DOWN, LEFT and RIGHT to manipulate character movement.
Mouse to manipulate character orientation.
Key 0 to toggle debugmode


Github Link:
https://github.com/Another-Ghost/CSC8503.git